//
//  aboutmeApp.swift
//  aboutme
//
//  Created by JZhang on 7/27/23.
//

import SwiftUI

@main
struct aboutmeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
